// SAMSA Archive Viewer v2 - Production Ready
class SamsaViewer {
  constructor() {
    this.data = null;
    this.conversations = [];
    this.currentConv = null;
    this.currentMessages = [];
    this.searchQuery = '';
    this.filterMode = 'all';
    this.isDarkMode = localStorage.getItem('samsaDarkMode') !== 'false';

    // Media (mainly local files saved by the extension under media/<conv>/...)
    this.mediaFolderHandle = null; // FileSystemDirectoryHandle, picked by the user
    this.resolvedMediaCache = new Map(); // relativePath -> blob: URL

    this.initElements();
    this.attachEventListeners();
    this.setupTheme();
    this.checkMediaFolderSupport();
  }

  checkMediaFolderSupport() {
    if (typeof window.showDirectoryPicker !== 'function') {
      this.btnLoadMediaFolder.style.display = 'none';
      this.mediaFolderStatus.textContent = '';
    }
  }

  initElements() {
    // Sidebar
    this.uploadArea = document.getElementById('upload-area');
    this.fileInput = document.getElementById('file-input');
    this.archiveInfo = document.getElementById('archive-info');
    this.searchSection = document.getElementById('search-section');
    this.convList = document.getElementById('conv-list');
    
    // Main content
    this.emptyState = document.getElementById('empty-state');
    this.convView = document.getElementById('conv-view');
    this.messagesContainer = document.getElementById('messages-container');
    
    // Headers
    this.convName = document.getElementById('conv-name');
    this.convMeta = document.getElementById('conv-meta');
    
    // Buttons
    this.btnOpenFile = document.getElementById('btn-open-file');
    this.btnLoadNew = document.getElementById('btn-load-new');
    this.btnExport = document.getElementById('btn-export');
    this.btnExportConv = document.getElementById('btn-export-conv');
    this.btnSearchMsgs = document.getElementById('btn-search-msgs');
    this.btnTheme = document.getElementById('btn-theme');
    this.btnLoadMediaFolder = document.getElementById('btn-load-media-folder');
    this.mediaFolderStatus = document.getElementById('media-folder-status');
    
    // Search
    this.searchInput = document.getElementById('search-input');
    this.filterSelect = document.getElementById('filter-select');
    this.msgSearchBox = document.getElementById('msg-search-box');
    this.msgSearchInput = document.getElementById('msg-search-input');
    this.btnCloseSearch = document.getElementById('btn-close-search');
    
    // Modal
    this.mediaModal = document.getElementById('media-modal');
    this.mediaViewer = document.getElementById('media-viewer');
    this.btnCloseModal = document.getElementById('btn-close-modal');
    
    // Stats
    this.convCount = document.getElementById('conv-count');
    this.msgCount = document.getElementById('msg-count');
    this.mediaCount = document.getElementById('media-count');
  }

  attachEventListeners() {
    // File upload
    this.uploadArea.addEventListener('click', () => this.fileInput.click());
    this.uploadArea.addEventListener('dragover', (e) => e.preventDefault());
    this.uploadArea.addEventListener('drop', (e) => {
      e.preventDefault();
      const files = e.dataTransfer.files;
      if (files[0]) this.loadFile(files[0]);
    });
    this.fileInput.addEventListener('change', (e) => {
      if (e.target.files[0]) this.loadFile(e.target.files[0]);
    });

    // Buttons
    this.btnOpenFile.addEventListener('click', () => this.fileInput.click());
    this.btnLoadNew.addEventListener('click', () => this.reset());
    this.btnExport.addEventListener('click', () => this.exportData());
    this.btnExportConv.addEventListener('click', () => this.exportConversation());
    this.btnSearchMsgs.addEventListener('click', () => this.toggleMessageSearch());
    this.btnCloseSearch.addEventListener('click', () => this.toggleMessageSearch());
    this.btnTheme.addEventListener('click', () => this.toggleTheme());
    this.btnLoadMediaFolder.addEventListener('click', () => this.linkMediaFolder());

    // Search
    this.searchInput.addEventListener('input', (e) => {
      this.searchQuery = e.target.value.toLowerCase();
      this.renderConversationList();
    });

    this.filterSelect.addEventListener('change', (e) => {
      this.filterMode = e.target.value;
      this.renderConversationList();
    });

    this.msgSearchInput.addEventListener('input', (e) => {
      this.filterMessages(e.target.value.toLowerCase());
    });

    // Modal
    this.btnCloseModal.addEventListener('click', () => this.closeMediaModal());
    this.mediaModal.addEventListener('click', (e) => {
      if (e.target === this.mediaModal) this.closeMediaModal();
    });
  }

  setupTheme() {
    if (!this.isDarkMode) {
      document.body.classList.add('light-mode');
      this.btnTheme.textContent = '☀️';
    }
  }

  loadFile(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        this.data = JSON.parse(e.target.result);
        this.conversations = this.data.conversations || [];
        this.show();
        this.updateStats();
        this.renderConversationList();
      } catch (err) {
        alert('Invalid JSON file: ' + err.message);
      }
    };
    reader.readAsText(file);
  }

  // The extension saves media to disk as relative paths like
  // "media/<conversation>/media_<timestamp>_<rand>.<ext>" inside the same
  // folder the user picked when archiving. The viewer is a separate page
  // loaded via file picker/drag-drop, so it has no automatic access to
  // those files — the user has to explicitly link that folder once per
  // session before relative paths can be resolved to something renderable.
  async linkMediaFolder() {
    if (typeof window.showDirectoryPicker !== 'function') return;
    try {
      this.mediaFolderHandle = await window.showDirectoryPicker({ mode: 'read' });
      this.resolvedMediaCache.clear();
      this.mediaFolderStatus.textContent = `Linked: ${this.mediaFolderHandle.name}`;
      this.mediaFolderStatus.classList.add('linked');
      // Re-render so any local-path media already on screen picks up the link
      if (this.currentConv) this.renderMessages();
    } catch (e) {
      // User cancelled the picker — not an error worth surfacing
    }
  }

  isLocalPath(url) {
    return !!url && !/^(https?:|blob:|data:)/i.test(url);
  }

  // Resolves a relative local media path (e.g. "media/Alice/media_123_4.mp4")
  // against the linked folder into a blob: URL the <img>/<video>/<audio>
  // tag can actually load. Remote (http/https) URLs are returned as-is.
  async resolveMediaUrl(url) {
    if (!this.isLocalPath(url)) return url;
    if (this.resolvedMediaCache.has(url)) return this.resolvedMediaCache.get(url);
    if (!this.mediaFolderHandle) return null; // not linked yet

    try {
      // The saved path is "media/<conv>/<file>"; the user links the *parent*
      // folder (the one containing the "media" subfolder), so walk it.
      const parts = url.split('/').filter(Boolean);
      let dirHandle = this.mediaFolderHandle;
      for (let i = 0; i < parts.length - 1; i++) {
        dirHandle = await dirHandle.getDirectoryHandle(parts[i]);
      }
      const fileHandle = await dirHandle.getFileHandle(parts[parts.length - 1]);
      const file = await fileHandle.getFile();
      const blobUrl = URL.createObjectURL(file);
      this.resolvedMediaCache.set(url, blobUrl);
      return blobUrl;
    } catch (e) {
      this.resolvedMediaCache.set(url, null);
      return null;
    }
  }

  show() {
    this.uploadArea.style.display = 'none';
    this.archiveInfo.style.display = 'flex';
    this.searchSection.style.display = 'flex';
    this.convList.style.display = 'flex';
    this.emptyState.style.display = 'none';
  }

  updateStats() {
    this.convCount.textContent = this.conversations.length;
    let totalMsgs = 0;
    let totalMedia = 0;
    
    this.conversations.forEach(c => {
      if (c.messages) {
        totalMsgs += c.messages.length;
        c.messages.forEach(m => {
          if (m.mediaUrls && m.mediaUrls.length > 0) {
            totalMedia += m.mediaUrls.length;
          }
        });
      }
    });
    
    this.msgCount.textContent = totalMsgs;
    this.mediaCount.textContent = totalMedia;
  }

  renderConversationList() {
    this.convList.innerHTML = '';
    
    let filtered = this.conversations;
    
    // Search filter
    if (this.searchQuery) {
      filtered = filtered.filter(c => {
        const name = (c.conversationName || c.conversationId || '').toLowerCase();
        const participants = (c.participants || []).map(p => (p.username || '').toLowerCase()).join(' ');
        return name.includes(this.searchQuery) || participants.includes(this.searchQuery);
      });
    }
    
    // Sort
    switch (this.filterMode) {
      case 'recent':
        filtered.sort((a, b) => (b.last_scraped || 0) - (a.last_scraped || 0));
        break;
      case 'oldest':
        filtered.sort((a, b) => (a.last_scraped || 0) - (b.last_scraped || 0));
        break;
      case 'a-z':
        filtered.sort((a, b) => (a.conversationName || '').localeCompare(b.conversationName || ''));
        break;
    }
    
    filtered.forEach(conv => {
      const item = document.createElement('div');
      item.className = 'conv-item';
      if (this.currentConv && this.currentConv.conversationId === conv.conversationId) {
        item.classList.add('active');
      }
      
      const name = conv.conversationName || conv.conversationId || 'Unknown';
      const msgCount = conv.messages ? conv.messages.length : 0;
      
      item.innerHTML = `
        <div class="conv-item-name">${this.escapeHtml(name)}</div>
        <div class="conv-item-meta">${msgCount} messages</div>
      `;
      
      item.addEventListener('click', () => this.selectConversation(conv));
      this.convList.appendChild(item);
    });
  }

  selectConversation(conv) {
    this.currentConv = conv;
    this.currentMessages = conv.messages || [];
    this.emptyState.style.display = 'none';
    this.convView.style.display = 'flex';
    
    this.convName.textContent = conv.conversationName || conv.conversationId;
    this.convMeta.textContent = `${this.currentMessages.length} messages`;
    
    this.renderConversationList();
    this.renderMessages();
  }

  renderMessages() {
    this.messagesContainer.innerHTML = '';
    
    this.currentMessages.forEach((msg, msgIndex) => {
      const item = document.createElement('div');
      item.className = 'message-item';
      
      // Get sender info
      const sender = this.currentConv.participants?.find(p => p.pk === msg.sender);
      const senderName = sender?.username || sender?.full_name || 'Unknown';
      const avatar = sender?.profile_pic_url || '';
      
      // Format time
      const date = new Date(msg.timestamp * 1000);
      const time = date.toLocaleTimeString();
      
      let avatarHtml = `<div class="message-avatar">${senderName[0]?.toUpperCase()}</div>`;
      if (avatar) {
        avatarHtml = `<div class="message-avatar"><img src="${avatar}" alt="${senderName}" onerror="this.parentElement.textContent='${senderName[0]?.toUpperCase() || '?'}'"></div>`;
      }
      
      let mediaHtml = '';
      if (msg.mediaUrls && msg.mediaUrls.length > 0) {
        mediaHtml = '<div class="message-media">';
        msg.mediaUrls.forEach((url, mediaIndex) => {
          const type = this.detectMediaType(url);
          const id = `media-${msgIndex}-${mediaIndex}`;

          if (type === 'video') {
            mediaHtml += `<div class="media-thumbnail" id="${id}" data-url="${this.escapeHtml(url)}" data-type="video">
              <video muted preload="metadata"></video>
              <div class="media-icon">▶️</div>
            </div>`;
          } else if (type === 'audio') {
            mediaHtml += `<div class="media-thumbnail" id="${id}" data-url="${this.escapeHtml(url)}" data-type="audio">
              <div class="media-icon">🔊</div>
            </div>`;
          } else if (type === 'image') {
            mediaHtml += `<div class="media-thumbnail" id="${id}" data-url="${this.escapeHtml(url)}" data-type="image">
              <img alt="Image">
            </div>`;
          } else {
            mediaHtml += `<div class="media-thumbnail" id="${id}" data-url="${this.escapeHtml(url)}" data-type="file">
              <div class="media-icon">📎</div>
            </div>`;
          }
        });
        mediaHtml += '</div>';
      }
      
      item.innerHTML = `
        ${avatarHtml}
        <div class="message-content">
          <div class="message-header">
            <span class="message-sender">${this.escapeHtml(senderName)}</span>
            <span class="message-time">${time}</span>
          </div>
          ${msg.text ? `<div class="message-text">${this.escapeHtml(msg.text)}</div>` : ''}
          ${mediaHtml}
        </div>
      `;
      
      this.messagesContainer.appendChild(item);
    });
    
    // Resolve & wire up every media thumbnail now that they're in the DOM
    this.messagesContainer.querySelectorAll('.media-thumbnail').forEach(thumb => this.hydrateThumbnail(thumb));
  }

  // Loads the actual src into a placeholder thumbnail (image/video poster),
  // falling back to a "missing media" state if the URL is unreachable or
  // is a local path that hasn't been linked to a folder yet.
  async hydrateThumbnail(thumb) {
    const url = thumb.dataset.url;
    const type = thumb.dataset.type;
    const resolved = await this.resolveMediaUrl(url);

    if (resolved === null) {
      this.markThumbnailBroken(thumb, this.isLocalPath(url));
      return;
    }

    thumb.dataset.resolvedUrl = resolved;

    if (type === 'image') {
      const img = thumb.querySelector('img');
      img.onerror = () => this.markThumbnailBroken(thumb, false);
      img.src = resolved;
    } else if (type === 'video') {
      const video = thumb.querySelector('video');
      video.onerror = () => this.markThumbnailBroken(thumb, false);
      video.src = resolved;
    }
    // audio/file thumbnails just show an icon — nothing more to hydrate

    thumb.addEventListener('click', () => this.openMediaModal(resolved, type));
  }

  markThumbnailBroken(thumb, needsMediaFolder) {
    thumb.classList.add('broken');
    thumb.innerHTML = `
      <div class="media-icon">${needsMediaFolder ? '📁' : '⚠️'}</div>
      <div class="media-broken-label">${needsMediaFolder ? 'Link media folder' : 'Media unavailable'}</div>
    `;
    if (needsMediaFolder) {
      thumb.title = 'This file was saved locally by the extension. Click "Link Media Folder" in the sidebar to view it.';
      thumb.addEventListener('click', () => this.linkMediaFolder());
    } else {
      thumb.title = 'This media could not be loaded.';
    }
  }

  // Extension-agnostic media type detection — handles signed CDN URLs with
  // query strings and no recognizable extension by also checking the path
  // portion, and falls back to a generic "file" type rather than guessing.
  detectMediaType(url) {
    if (!url) return 'file';
    const path = url.split('?')[0].split('#')[0];
    if (/\.(jpe?g|png|gif|webp|bmp|heic)$/i.test(path)) return 'image';
    if (/\.(mp4|webm|mov|m4v|ogg)$/i.test(path)) return 'video';
    if (/\.(mp3|m4a|wav|aac|opus)$/i.test(path)) return 'audio';
    // Instagram voice notes / reel renditions are sometimes served from
    // CDN paths that carry the type in the URL rather than the extension
    if (/audio/i.test(url)) return 'audio';
    if (/video|reel|clip/i.test(url)) return 'video';
    return 'file';
  }

  filterMessages(query) {
    if (!query) {
      this.renderMessages();
      return;
    }
    
    const filtered = this.currentMessages.filter(msg => {
      const text = (msg.text || '').toLowerCase();
      return text.includes(query);
    });
    
    this.messagesContainer.innerHTML = '';
    filtered.forEach(msg => {
      // Render filtered message
      const item = document.createElement('div');
      item.className = 'message-item';
      const sender = this.currentConv.participants?.find(p => p.pk === msg.sender);
      const senderName = sender?.username || 'Unknown';
      const date = new Date(msg.timestamp * 1000);
      const time = date.toLocaleTimeString();
      
      const text = this.escapeHtml(msg.text || '');
      const highlighted = text.replace(
        new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\\\]/g, '\\\\$&')})`, 'gi'),
        '<mark>$1</mark>'
      );
      
      item.innerHTML = `
        <div class="message-avatar">${senderName[0]?.toUpperCase()}</div>
        <div class="message-content">
          <div class="message-header">
            <span class="message-sender">${this.escapeHtml(senderName)}</span>
            <span class="message-time">${time}</span>
          </div>
          <div class="message-text">${highlighted}</div>
        </div>
      `;
      
      this.messagesContainer.appendChild(item);
    });
  }

  openMediaModal(url, type) {
    this.mediaViewer.innerHTML = '';
    
    if (type === 'image') {
      const img = document.createElement('img');
      img.src = url;
      this.mediaViewer.appendChild(img);
    } else if (type === 'video') {
      const video = document.createElement('video');
      video.src = url;
      video.controls = true;
      video.autoplay = true;
      this.mediaViewer.appendChild(video);
    } else if (type === 'audio') {
      const audio = document.createElement('audio');
      audio.src = url;
      audio.controls = true;
      audio.autoplay = true;
      this.mediaViewer.appendChild(audio);
    } else {
      const link = document.createElement('a');
      link.href = url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.className = 'btn btn-primary';
      link.textContent = 'Open file';
      this.mediaViewer.appendChild(link);
    }
    
    this.mediaModal.style.display = 'flex';
  }

  closeMediaModal() {
    this.mediaModal.style.display = 'none';
  }

  toggleMessageSearch() {
    const isVisible = this.msgSearchBox.style.display !== 'none';
    this.msgSearchBox.style.display = isVisible ? 'none' : 'flex';
    if (!isVisible) {
      this.msgSearchInput.focus();
    } else {
      this.renderMessages();
    }
  }

  exportData() {
    const json = JSON.stringify(this.data, null, 2);
    this.downloadFile(json, 'samsa-archive.json', 'application/json');
  }

  exportConversation() {
    if (!this.currentConv) return;
    
    const json = JSON.stringify(this.currentConv, null, 2);
    const filename = `${(this.currentConv.conversationName || 'conv').replace(/[^a-z0-9]/gi, '_')}.json`;
    this.downloadFile(json, filename, 'application/json');
  }

  downloadFile(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  toggleTheme() {
    this.isDarkMode = !this.isDarkMode;
    localStorage.setItem('samsaDarkMode', this.isDarkMode);
    
    if (this.isDarkMode) {
      document.body.classList.remove('light-mode');
      this.btnTheme.textContent = '🌙';
    } else {
      document.body.classList.add('light-mode');
      this.btnTheme.textContent = '☀️';
    }
  }

  reset() {
    this.data = null;
    this.conversations = [];
    this.currentConv = null;
    this.currentMessages = [];
    this.searchQuery = '';

    // Release any blob: URLs created for locally-linked media
    this.resolvedMediaCache.forEach(url => {
      if (url) URL.revokeObjectURL(url);
    });
    this.resolvedMediaCache.clear();
    
    this.uploadArea.style.display = 'block';
    this.archiveInfo.style.display = 'none';
    this.searchSection.style.display = 'none';
    this.convList.style.display = 'none';
    this.convView.style.display = 'none';
    this.emptyState.style.display = 'flex';
    this.fileInput.value = '';
  }

  escapeHtml(text) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
  }
}

// Initialize viewer
document.addEventListener('DOMContentLoaded', () => {
  new SamsaViewer();
});
