let db = null;
let currentState = 'stopped';
let scrapeQueue = [];
let pausedQueue = []; // Holds the remaining queue while paused, so RESUME picks up where PAUSE left off
let currentThreadId = null; // The conversation actively being fetched right now (already shifted out of scrapeQueue)
let isScraping = false;
let globalConvMap = new Map();

let liveModeInterval = null;
let liveModeIds = [];

// Session & State Persistence
let sessionCheckpoint = {};
let mediaHashCache = new Map(); // {hash -> {url, timestamp, conversationId}}

// User-configurable settings (Settings panel in panel.html), applied live —
// no need to reload the extension for changes to take effect.
let settings = {
  autoDownload: true,
  mediaQuality: 'medium',
  skipReels: true,
  retryAttempts: 3,
  retryDelay: 5000,
  requestTimeout: 30000,
  logVerbosity: 'info',
  parallelConvs: 1,
  apiEndpoint: '',
  debugMode: false
};

function applySettings(newSettings) {
  settings = { ...settings, ...(newSettings || {}) };
  log(`Settings updated (retries=${settings.retryAttempts}, skipReels=${settings.skipReels}, verbosity=${settings.logVerbosity})`, 'info');
}

// 3s–9s random delay
const getRandomDelay = () => Math.random() * (9000 - 3000) + 3000;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// Structured Logging
// Verbosity is a floor: 'debug' shows everything, 'info' hides debug noise,
// 'warning' hides info+debug ("errors only" per the settings UI), 'error'
// hides everything except error ("critical only"). 'success' always passes
// through since the panel relies on it to know when to refresh stats.
const LOG_LEVELS = { debug: 0, info: 1, warning: 2, error: 3, success: 4 };
function log(message, level = 'info', context = {}) {
  const verbosityFloor = LOG_LEVELS[settings.logVerbosity] ?? LOG_LEVELS.info;
  if (level !== 'success' && LOG_LEVELS[level] < verbosityFloor) return;

  const timestamp = new Date().toLocaleTimeString();
  const logEntry = {
    timestamp,
    level,
    message,
    context,
    date: new Date().toISOString()
  };
  chrome.runtime.sendMessage({ type: "LOG", payload: `[${timestamp}] ${message}`, level }).catch(() => {});
  chrome.storage.local.get('samsaLogs', (result) => {
    const logs = result.samsaLogs || [];
    logs.push(logEntry);
    if (logs.length > 500) logs.shift(); // Keep last 500
    chrome.storage.local.set({ samsaLogs: logs });
  });
}

// SHA-256 Hashing for media deduplication
async function hashUrl(url) {
  const encoder = new TextEncoder();
  const data = encoder.encode(url);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Filter out reels, posts, stories—only keep DM media (photos, videos, voice notes)
// Honors the "Skip reels/posts" user setting: when disabled, reel/post/story
// items shared in a DM are kept instead of silently dropped.
function isDMMediaItem(item) {
  if (!item) return false;
  const type = item.item_type || '';
  if (settings.skipReels) {
    const excludeTypes = ['reel', 'post', 'story', 'carousel', 'clip'];
    if (excludeTypes.includes(type)) return false;
  }
  // Accept text, photo, video, audio, voice_media, media (+ reel/post/story/clip if skipReels is off)
  const acceptTypes = ['text', 'photo', 'video', 'audio', 'voice_media', 'media', 'share', 'link', 'reel', 'post', 'story', 'carousel', 'clip'];
  return acceptTypes.includes(type) || !type;
}

function extractMediaUrls(obj, urls = new Set()) {
  if (!obj || typeof obj !== 'object') return urls;
  
  if (Array.isArray(obj)) {
    obj.forEach(o => extractMediaUrls(o, urls));
  } else {
    let foundMedia = false;
    if (obj.video_versions && Array.isArray(obj.video_versions) && obj.video_versions.length > 0) {
      const best = obj.video_versions.slice().sort((a,b) => ((b.width||0)*(b.height||0)) - ((a.width||0)*(a.height||0)))[0];
      if (best && best.url) { urls.add(best.url); foundMedia = true; }
    } 
    else if (obj.image_versions2 && obj.image_versions2.candidates && Array.isArray(obj.image_versions2.candidates)) {
      const best = obj.image_versions2.candidates.slice().sort((a,b) => ((b.width||0)*(b.height||0)) - ((a.width||0)*(a.height||0)))[0];
      if (best && best.url) { urls.add(best.url); foundMedia = true; }
    }
    
    if (obj.audio && obj.audio.audio_src) {
      urls.add(obj.audio.audio_src);
      foundMedia = true;
    }
    
    if (!foundMedia) {
      for (const key of Object.keys(obj)) {
        if (key !== 'user' && key !== 'owner' && key !== 'sender') {
          extractMediaUrls(obj[key], urls);
        }
      }
    }
  }
  return urls;
}

function initDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("samsa_archive", 2); // Bumped to v2 for schema upgrade
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      const oldVersion = event.oldVersion;

      // Create or upgrade conversations store
      if (!db.objectStoreNames.contains("conversations")) {
        const store = db.createObjectStore("conversations", { keyPath: "conversationId" });
        store.createIndex("last_scraped", "last_scraped", { unique: false });
      } else if (oldVersion < 2) {
        // Upgrade existing store
        const store = event.target.transaction.objectStore("conversations");
        store.createIndex("last_scraped", "last_scraped", { unique: false });
      }

      // Media URLs with deduplication tracking
      if (!db.objectStoreNames.contains("media_urls")) {
        const store = db.createObjectStore("media_urls", { keyPath: "hash" }); // Use hash instead of url for dedup
        store.createIndex("url", "url", { unique: false });
        store.createIndex("downloaded", "downloaded", { unique: false });
      }

      // Session checkpoints for resumption
      if (!db.objectStoreNames.contains("session_state")) {
        db.createObjectStore("session_state", { keyPath: "id" });
      }

      // Message dedup cache
      if (!db.objectStoreNames.contains("message_cache")) {
        const store = db.createObjectStore("message_cache", { keyPath: "msgKey" });
        store.createIndex("conversationId", "conversationId", { unique: false });
      }
    };
    
    request.onsuccess = (event) => {
      db = event.target.result;
      log("Database initialized v" + db.version);
      resolve(db);
    };
    
    request.onerror = (event) => {
      log("Database error: " + event.target.error.message, 'error');
      reject(event.target.error);
    };
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  await initDB();
  chrome.storage.local.set({ 
    state: 'idle', 
    activeSince: null,
    samsaSettings: settings
  });
});

function loadSettings() {
  chrome.storage.local.get('samsaSettings', (result) => {
    if (result.samsaSettings) {
      settings = { ...settings, ...result.samsaSettings };
    }
  });
}

chrome.action.onClicked.addListener(async () => {
  const panelUrl = chrome.runtime.getURL("panel.html");
  const tabs = await chrome.tabs.query({ url: panelUrl });
  if (tabs.length > 0) {
    await chrome.windows.update(tabs[0].windowId, { focused: true });
    return;
  }
  await chrome.windows.create({
    url: panelUrl,
    type: "popup",
    width: 500,
    height: 720
  });
});

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ url: "*://www.instagram.com/*" });
  return tabs[0]; // Take first IG tab
}

async function fetchApiViaTab(tabId, url, retries = null) {
  const maxAttempts = retries ?? settings.retryAttempts;
  const baseDelay = settings.retryDelay;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, { action: 'proxyIgFetch', url }, (response) => {
          if (chrome.runtime.lastError) {
            let errMessage = chrome.runtime.lastError.message;
            if (errMessage.includes("Receiving end does not exist")) {
              errMessage = "Content script disconnected. Please RELOAD Instagram tab.";
            }
            return reject(new Error(errMessage));
          }
          if (!response) return reject(new Error("No response from tab"));
          if (response.ok) resolve(response.json);
          else reject(new Error(response.error || "API error"));
        });
      });
    } catch (e) {
      const isLastAttempt = attempt === maxAttempts;
      log(
        `API fetch attempt ${attempt}/${maxAttempts} failed: ${e.message}`,
        isLastAttempt ? 'error' : 'warning',
        { url, attempt }
      );
      
      if (!isLastAttempt) {
        const delay = Math.min(baseDelay * attempt, 30000); // Exponential backoff
        await sleep(delay);
      } else {
        throw e;
      }
    }
  }
}

async function fetchConversations() {
  const tab = await getActiveTab();
  if (!tab) {
    log("No active Instagram tab to fetch conversations", 'error');
    return;
  }
  log("Fetching inbox...", 'info');
  try {
    const json = await fetchApiViaTab(tab.id, "https://www.instagram.com/api/v1/direct_v2/inbox/?persistentBadging=true&folder=&limit=20", 2);
    if (json && json.inbox && json.inbox.threads) {
      const convs = json.inbox.threads.map(t => ({
        id: t.thread_id,
        name: t.thread_title || (t.users && t.users.map(u => u.username).join(', ')) || t.thread_id
      }));
      convs.forEach(c => globalConvMap.set(c.id, c.name));
      chrome.runtime.sendMessage({ type: "CONVERSATIONS_FOUND", payload: convs }).catch(() => {});
      log(`Found ${convs.length} conversations`, 'success', { count: convs.length });
    }
  } catch (e) {
    log(`Failed to fetch conversations: ${e.message}`, 'error', { error: e.message });
  }
}

async function scrapeThread(tabId, threadId) {
  chrome.runtime.sendMessage({ type: "CONV_STATUS_UPDATE", payload: { conversationId: threadId, status: "Scraping" } }).catch(()=>{});
  let cursor = "";
  let keepFetching = true;
  let pagesFetched = 0;
  let duplicatesSkipped = 0;
  
  // Load checkpoint for this conversation
  const checkpoint = sessionCheckpoint[threadId] || { cursor: "", pagesFetched: 0 };
  cursor = checkpoint.cursor;
  pagesFetched = checkpoint.pagesFetched;
  
  while (keepFetching) {
    if (currentState !== 'active') {
      // Save checkpoint before breaking
      saveSessionCheckpoint(threadId, { cursor, pagesFetched });
      break;
    }

    let url = `https://www.instagram.com/api/v1/direct_v2/threads/${threadId}/`;
    if (cursor) url += `?cursor=${cursor}`;
    
    log(`Fetching ${threadId} (Page ${pagesFetched + 1})`, 'info', { threadId, page: pagesFetched + 1 });
    
    try {
      const json = await fetchApiViaTab(tabId, url); // Uses settings.retryAttempts
      const thread = json.thread || (json.threads && json.threads[0]);
      if (!thread || !thread.items) {
        throw new Error("Invalid thread structure");
      }
      
      const parsedMessages = [];
      let filteredCount = 0;
      for (const item of thread.items) {
        // FILTER: Skip reels, posts, stories—only keep DM media
        if (!isDMMediaItem(item)) {
          filteredCount++;
          log(`Filtered non-DM item (type: ${item.item_type || 'unknown'})`, 'debug', { threadId, itemType: item.item_type });
          continue;
        }

        let text = item.text || "";
        const mediaUrls = Array.from(extractMediaUrls(item));
        
        let timestamp = parseInt(item.timestamp);
        if (timestamp > 10000000000000) timestamp = Math.floor(timestamp / 1000);

        // Check if message already exists (dedup by item_id or text+timestamp)
        const msgKey = item.item_id || `${timestamp}_${text}`;
        const isDuplicate = await checkMessageExists(threadId, msgKey);
        if (isDuplicate) {
          duplicatesSkipped++;
          log(`Skipped duplicate message (key: ${msgKey})`, 'debug', { threadId, msgKey });
          continue;
        }

        parsedMessages.push({
          item_id: item.item_id,
          item_type: item.item_type,
          text: text,
          mediaUrls: mediaUrls,
          timestamp: timestamp,
          sender: item.user_id,
          msgKey: msgKey
        });
      }
      
      if (parsedMessages.length > 0) {
        const convName = globalConvMap.get(threadId) || threadId;
        const batchPayload = {
          conversationId: threadId,
          conversationName: convName,
          messages: parsedMessages,
          participants: thread.users ? thread.users.map(u => ({
            pk: u.pk,
            username: u.username,
            full_name: u.full_name,
            profile_pic_url: u.profile_pic_url
          })) : []
        };
        
        await saveConversationBatch(batchPayload);
        chrome.runtime.sendMessage({ type: "BATCH_SCRAPED", payload: batchPayload }).catch(() => {});
        log(`Saved ${parsedMessages.length} messages (${duplicatesSkipped} duplicates, ${filteredCount} non-DM items skipped)`, 'success', { threadId });
      } else if (duplicatesSkipped > 0 || filteredCount > 0) {
        log(`No new messages (${duplicatesSkipped} duplicates, ${filteredCount} non-DM items skipped)`, 'info', { threadId });
      }

      pagesFetched++;
      if (thread.oldest_cursor) {
        cursor = thread.oldest_cursor;
        saveSessionCheckpoint(threadId, { cursor, pagesFetched });
        await sleep(getRandomDelay());
      } else {
        keepFetching = false;
        log(`Completed ${threadId} (${pagesFetched} pages)`, 'success', { threadId });
      }
    } catch (e) {
      log(`Error fetching ${threadId}: ${e.message}`, 'error', { threadId, error: e.message });
      saveSessionCheckpoint(threadId, { cursor, pagesFetched }); // Save state before failing
      throw e;
    }
  }
}

async function checkMessageExists(conversationId, msgKey) {
  if (!db) await initDB();
  return new Promise((resolve) => {
    const tx = db.transaction(["message_cache"], "readonly");
    const store = tx.objectStore("message_cache");
    const idx = store.index("conversationId");
    const range = IDBKeyRange.only(conversationId);
    
    const req = idx.getAll(range);
    req.onsuccess = (e) => {
      const exists = e.target.result.some(m => m.msgKey === msgKey);
      resolve(exists);
    };
    req.onerror = () => resolve(false);
  });
}

function saveSessionCheckpoint(threadId, checkpoint) {
  sessionCheckpoint[threadId] = checkpoint;
  chrome.storage.local.set({
    samsaCheckpoint: sessionCheckpoint
  });
}

async function loadSessionCheckpoints() {
  return new Promise((resolve) => {
    chrome.storage.local.get('samsaCheckpoint', (result) => {
      sessionCheckpoint = result.samsaCheckpoint || {};
      resolve(sessionCheckpoint);
    });
  });
}

async function startQueue(ids) {
  scrapeQueue = ids;
  if (isScraping) return;
  isScraping = true;
  currentState = 'active';
  
  await loadSessionCheckpoints(); // Restore previous state
  
  chrome.storage.local.set({ state: 'active', activeSince: Date.now() });
  broadcastState();
  
  const tab = await getActiveTab();
  if (!tab) {
    log("No active Instagram tab found", 'error');
    isScraping = false;
    return;
  }
  
  while (scrapeQueue.length > 0) {
    if (currentState !== 'active') {
      log(`Paused. Can resume from checkpoint later.`, 'warning');
      break;
    }
    const threadId = scrapeQueue.shift();
    currentThreadId = threadId;
    try {
      await scrapeThread(tab.id, threadId);
      chrome.runtime.sendMessage({ type: "CONV_STATUS_UPDATE", payload: { conversationId: threadId, status: "Done" } }).catch(()=>{});
    } catch (e) {
      chrome.runtime.sendMessage({ type: "CONV_STATUS_UPDATE", payload: { conversationId: threadId, status: "Error" } }).catch(()=>{});
      log(`Failed to scrape ${threadId}: ${e.message}`, 'error', { threadId });

      // Graceful degradation: a connection-level failure (tab gone, content
      // script disconnected) will fail identically for every remaining
      // conversation too. Rather than burn through the whole queue hitting
      // the same error, auto-pause so the checkpoint is preserved and the
      // user can fix the tab and RESUME instead of losing the rest of the run.
      if (isFatalConnectionError(e)) {
        scrapeQueue.unshift(threadId); // put it back — it never actually ran
        currentThreadId = null;
        currentState = 'paused';
        pausedQueue = scrapeQueue.slice();
        chrome.storage.local.set({ state: 'paused' });
        broadcastState();
        log(`Auto-paused: ${e.message}. Reload the Instagram tab, then press RESUME.`, 'warning');
        break;
      }
    }
    currentThreadId = null;
    await sleep(getRandomDelay());
  }
  
  isScraping = false;
  if (scrapeQueue.length === 0 && currentState === 'active') {
    log(`All conversations processed`, 'success');
    currentState = 'stopped';
    chrome.storage.local.set({ state: 'stopped' });
    broadcastState();
  }
}

function isFatalConnectionError(e) {
  const msg = (e && e.message) || '';
  return msg.includes('Content script disconnected') || msg.includes('No active Instagram tab') || msg.includes('No response from tab');
}

// PAUSE flips currentState, but the in-flight fetch/sleep inside startQueue's
// loop needs a moment to notice and unwind (isScraping -> false) before a new
// queue can start. Without this, a fast RESUME click right after PAUSE would
// silently no-op against startQueue's own re-entrancy guard.
async function resumeWhenReady(ids, attempts = 10) {
  if (isScraping && attempts > 0) {
    await sleep(300);
    return resumeWhenReady(ids, attempts - 1);
  }
  startQueue(ids);
}

async function scrapeThreadLive(tabId, threadId) {
  let url = `https://www.instagram.com/api/v1/direct_v2/threads/${threadId}/`;
  const json = await fetchApiViaTab(tabId, url);
  const thread = json.thread || (json.threads && json.threads[0]);
  if (!thread || !thread.items) return;

  const parsedMessages = [];
  const apiItemIds = new Set();
  let oldestTimestampInFetch = Infinity;

  for (const item of thread.items) {
    apiItemIds.add(item.item_id);
    let text = item.text || "";
    const mediaUrls = Array.from(extractMediaUrls(item));
    let timestamp = parseInt(item.timestamp);
    if (timestamp > 10000000000000) timestamp = Math.floor(timestamp / 1000);

    if (timestamp < oldestTimestampInFetch) oldestTimestampInFetch = timestamp;

    parsedMessages.push({
      item_id: item.item_id,
      item_type: item.item_type,
      text: text,
      mediaUrls: mediaUrls,
      timestamp: timestamp,
      sender: item.user_id
    });
  }

  const convName = globalConvMap.get(threadId) || threadId;
  const batchPayload = {
    conversationId: threadId,
    conversationName: convName,
    messages: parsedMessages,
    participants: thread.users ? thread.users.map(u => ({
      pk: u.pk,
      username: u.username,
      full_name: u.full_name,
      profile_pic_url: u.profile_pic_url
    })) : [],
    isLive: true,
    apiItemIds: Array.from(apiItemIds),
    oldestTimestampInFetch: oldestTimestampInFetch
  };

  await saveConversationBatch(batchPayload);
  chrome.runtime.sendMessage({ type: "BATCH_SCRAPED", payload: batchPayload }).catch(() => {});
}

async function startLiveMode(ids) {
  liveModeIds = ids;
  if (currentState === 'active') return;
  currentState = 'live';
  chrome.storage.local.set({ state: 'live', activeSince: Date.now() });
  broadcastState();

  if (liveModeInterval) clearInterval(liveModeInterval);
  
  const liveScrape = async () => {
    if (currentState !== 'live') return;
    const tab = await getActiveTab();
    if (!tab) return;
    for (const threadId of liveModeIds) {
      if (currentState !== 'live') break;
      try {
        await scrapeThreadLive(tab.id, threadId);
      } catch (e) {
        chrome.runtime.sendMessage({ type: "LOG", payload: `[Live] Error ${threadId}: ${e.message}`, level: 'error' }).catch(()=>{});
      }
      await sleep(2000);
    }
  };
  
  liveScrape();
  liveModeInterval = setInterval(liveScrape, 15000); // 15 seconds
}

async function saveConversationBatch(batch) {
  if (!db) await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["conversations", "media_urls"], "readwrite");
    const convStore = transaction.objectStore("conversations");
    const mediaStore = transaction.objectStore("media_urls");
    
    const getReq = convStore.get(batch.conversationId);
    getReq.onsuccess = (e) => {
      let data = e.target.result;
      if (!data) {
        data = {
          conversationId: batch.conversationId,
          participants: batch.participants || [],
          messages: [],
          last_scraped: Date.now()
        };
      }
      
      const existingMsgIds = new Set(data.messages.map(m => m.item_id || (m.timestamp + m.text)));
      let newCount = 0;
      for (const msg of batch.messages) {
        const key = msg.item_id || (msg.timestamp + msg.text);
        if (!existingMsgIds.has(key)) {
          data.messages.push(msg);
          for (const url of msg.mediaUrls) {
            mediaStore.put({ url: url, conversationId: batch.conversationId, timestamp: msg.timestamp });
          }
          if (batch.isLive) newCount++;
        }
      }
      
      if (batch.isLive && newCount > 0) {
        chrome.notifications.create({
          type: 'basic',
          iconUrl: chrome.runtime.getURL('logo.webp'),
          title: 'Samsa: New Message',
          message: `${newCount} new message(s) in ${batch.conversationName}`
        });
      }

      if (batch.isLive && batch.apiItemIds && batch.oldestTimestampInFetch !== Infinity) {
        const apiIds = new Set(batch.apiItemIds);
        let deletedCount = 0;
        data.messages.forEach(m => {
           if (m.timestamp >= batch.oldestTimestampInFetch && m.item_id) {
               if (!apiIds.has(m.item_id) && !m.deleted) {
                   m.deleted = true;
                   deletedCount++;
               }
           }
        });
        if (deletedCount > 0) {
            chrome.runtime.sendMessage({ type: "LOG", payload: `[Live] Detected ${deletedCount} deleted messages in ${batch.conversationName}`, level: 'warning' }).catch(()=>{});
            chrome.notifications.create({
              type: 'basic',
              iconUrl: chrome.runtime.getURL('logo.webp'),
              title: 'Samsa: Message Deleted',
              message: `${deletedCount} message(s) were deleted in ${batch.conversationName}`
            });
        }
      }
      
      data.messages.sort((a, b) => a.timestamp - b.timestamp);
      
      data.last_scraped = Date.now();
        // Merge participant objects, ensuring unique entries by pk
        const participantMap = new Map();
        // Existing participants may be simple strings or objects; normalize to objects
        (data.participants || []).forEach(p => {
          if (typeof p === 'string') {
            participantMap.set(p, { pk: p });
          } else if (p && p.pk) {
            participantMap.set(p.pk, p);
          }
        });
        (batch.participants || []).forEach(p => {
          if (p && p.pk) {
            participantMap.set(p.pk, p);
          }
        });
        data.participants = Array.from(participantMap.values());
        if (batch.conversationName) {
          data.name = batch.conversationName;
        }
      
      convStore.put(data);
      resolve();
    };
    getReq.onerror = (e) => reject(e.target.error);
  });
}

function broadcastState() {
  chrome.storage.local.get(['state', 'activeSince', 'idleSince'], (result) => {
    chrome.runtime.sendMessage({ type: "STATE_UPDATE", payload: result }).catch(() => {});
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "CONTENT_READY") {
    // Inject automatically triggers this. Fetch list if idle.
    if (currentState !== 'active') {
      fetchConversations();
    }
    return;
  }

  if (message.type === "FETCH_CONVERSATIONS") {
    fetchConversations();
    sendResponse({success:true});
    return true;
  }

  if (message.type === "GET_DB_DATA") {
    getAllData().then(data => sendResponse(data));
    return true;
  }

  if (message.type === "CLEAR_DB") {
    clearDB().then(() => sendResponse({success:true}));
    return true;
  }

  if (message.type === "UPDATE_LOCAL_URLS") {
    updateLocalUrls(message.payload).then(() => sendResponse({success:true}));
    return true;
  }

  if (message.type === "MANUAL_START") {
    startQueue(message.ids);
    sendResponse({success:true});
    return true;
  }

  if (message.type === "PAUSE_CYCLE") {
    // The scrape loop in scrapeThread/startQueue checks currentState on every
    // iteration and saves a checkpoint before breaking, so pausing is just a
    // state flip — no separate "pause" logic needed, resumption reuses the
    // same checkpoint system as crash recovery. The in-flight thread (already
    // shifted out of scrapeQueue) is re-added so it isn't skipped on resume.
    if (currentState === 'active') {
      pausedQueue = currentThreadId ? [currentThreadId, ...scrapeQueue] : scrapeQueue.slice();
      currentState = 'paused';
      chrome.storage.local.set({ state: 'paused' });
      broadcastState();
      log("Paused by user. Progress checkpointed.", 'warning');
    }
    sendResponse({success:true});
    return true;
  }

  if (message.type === "RESUME_CYCLE") {
    const idsToResume = pausedQueue.length > 0 ? pausedQueue : scrapeQueue;
    pausedQueue = [];
    resumeWhenReady(idsToResume);
    sendResponse({success:true});
    return true;
  }

  if (message.type === "STOP_CYCLE") {
    currentState = 'stopped';
    pausedQueue = [];
    chrome.storage.local.set({ state: 'stopped' });
    broadcastState();
    sendResponse({success:true});
  }

  if (message.type === "UPDATE_SETTINGS") {
    applySettings(message.payload);
    sendResponse({success:true});
  }

  if (message.type === "START_LIVE_MODE") {
    startLiveMode(message.ids);
    sendResponse({success:true});
    return true;
  }

  if (message.type === "STOP_LIVE_MODE") {
    if (liveModeInterval) clearInterval(liveModeInterval);
    currentState = 'stopped';
    chrome.storage.local.set({ state: 'stopped' });
    broadcastState();
    sendResponse({success:true});
  }

  if (message.type === "CHECK_STATE") {
    chrome.storage.local.get(['state', 'activeSince', 'idleSince'], (result) => {
      sendResponse(result);
    });
    return true;
  }
});

async function getAllData() {
  if (!db) await initDB();
  return new Promise((resolve) => {
    const transaction = db.transaction(["conversations", "media_urls"], "readonly");
    const data = { conversations: [], media_urls: [] };
    
    transaction.objectStore("conversations").getAll().onsuccess = (e) => {
      data.conversations = e.target.result;
      transaction.objectStore("media_urls").getAll().onsuccess = (e2) => {
        data.media_urls = e2.target.result;
        resolve(data);
      }
    };
  });
}

async function clearDB() {
  if (!db) await initDB();
  return new Promise((resolve) => {
    const transaction = db.transaction(["conversations", "media_urls"], "readwrite");
    transaction.objectStore("conversations").clear();
    transaction.objectStore("media_urls").clear();
    transaction.oncomplete = () => resolve();
  });
}

async function updateLocalUrls(batch) {
  if (!db) await initDB();
  return new Promise((resolve) => {
    const transaction = db.transaction(["conversations"], "readwrite");
    const convStore = transaction.objectStore("conversations");
    const getReq = convStore.get(batch.conversationId);
    getReq.onsuccess = (e) => {
      let data = e.target.result;
      if (data) {
        const updateMap = new Map();
        batch.messages.forEach(m => {
          updateMap.set(m.item_id || (m.timestamp + m.text), m.mediaUrls);
        });
        data.messages.forEach(m => {
          const key = m.item_id || (m.timestamp + m.text);
          if (updateMap.has(key)) m.mediaUrls = updateMap.get(key);
        });
        convStore.put(data);
      }
      resolve();
    };
  });
}

initDB();
loadSettings();
